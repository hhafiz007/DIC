import re

def lowerRe(x):
  stopwords_file = open("stopwords.txt", "r")
  stopwords = stopwords_file.readlines()
  stopwords = [word.strip() for word in stopwords]  # remove any whitespace or newline characters
  stopwords_file.close()
  wordList = []
  words = x.split(' ')
  for word in words:
    word = word.lower()
    word = re.sub("^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$", "", word)
    if word and word not in stopwords:
      wordList.append(word)

  return wordList    



def countWords(sc, files, weirdPartition = False):
  output = None
  for file in files:
    if weirdPartition:
      lines = sc.textFile(file, minPartitions = len(file)) 
    else:
      lines = sc.textFile(file) 
      counts = lines.flatMap(lambda x:lowerRe(x)) \
              .map(lambda x: (x, 1)) \
               


    if output == None:
      output = counts
    else:
      output = output.union(counts)
  return output.reduceByKey(lambda x, y: x + y).sortBy(lambda x: x[1], ascending=False)

if __name__ == '__main__':
  from pyspark.context import SparkContext
  sc = SparkContext('local', 'test')

  countWords(sc, ["A room with a view.txt","Alice Adventure.txt","Flutter of the Gold Leaf.txt","pride & prejudice.txt","Romeo & Juliet.txt","Sir Isaac Brock.txt","The Delinquent.txt","The Great gatsby.txt","Two months in a cap.txt","Popular Amusements.txt", "war and peace.txt"]).saveAsTextFile("output")
