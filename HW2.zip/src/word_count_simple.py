import re

def lowerRe(x):
  stopwords_file = open("stopwords.txt", "r")
  stopwords = stopwords_file.readlines()
  stopwords = [word.strip() for word in stopwords]  # remove any whitespace or newline characters
  stopwords_file.close()
  wordList = []
  words = x.split(' ')
  for word in words:
    word = word.lower()
    word = re.sub("^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$", "", word)
    if word and word not in stopwords:
      wordList.append(word)

  return wordList    




def countWords(sc, file):
  lines = sc.textFile(file) 
  
 
  
  counts = lines.flatMap(lambda x:lowerRe(x)) \
               .map(lambda x: (x, 1)) \
              .reduceByKey(lambda a,b: a + b) \
              .sortBy(lambda x: x[1], ascending=False)

  return counts

if __name__ == '__main__':
  from pyspark.context import SparkContext
  
  sc = SparkContext('local', 'test')




  counts = countWords(sc, "war and peace.txt")
  counts.sortBy(lambda x: x[1], False).saveAsTextFile("output")
